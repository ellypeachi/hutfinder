import { useEffect, useState } from "react";

export default function App() {
  const [huts, setHuts] = useState([]);
  const [query, setQuery] = useState("");
  const [status, setStatus] = useState("loading"); // loading | ready | error

  useEffect(() => {
    fetch("/huts.json")
      .then((res) => {
        if (!res.ok) throw new Error(res.status);
        return res.json();
      })
      .then((data) => {
        setHuts(data);
        setStatus("ready");
      })
      .catch(() => setStatus("error"));
  }, []);

  const typeLabel = {
    schutzhuette: "Schutzhütte",
    alm: "Alm",
    jausenstation: "Jausenstation",
  };

  const filtered = huts.filter((h) =>
    h.name.toLowerCase().includes(query.toLowerCase())
  );

  return (
    <div style={{ background: "#fff", color: "#1a1a1a", minHeight: "100vh", width: "100%" }}>
      <div style={{ maxWidth: 640, margin: "0 auto", padding: "2rem 1rem", fontFamily: "system-ui, sans-serif", textAlign: "left" }}>
        <h1 style={{ fontSize: "1.6rem", marginBottom: "0.25rem" }}>Hüttenfinder</h1>
        <p style={{ color: "#666", marginTop: 0 }}>
          {status === "ready" ? `${filtered.length} of ${huts.length} huts` : ""}
        </p>

        {status === "loading" && <p>Loading huts…</p>}
        {status === "error" && (
          <p style={{ color: "#c00" }}>
            Couldn't load huts.json — check it's in the <code>public</code> folder.
          </p>
        )}

        {status === "ready" && (
          <>
            <input
              type="text"
              placeholder="Search by name…"
              value={query}
              onChange={(e) => setQuery(e.target.value)}
              style={{ width: "100%", padding: "0.6rem", fontSize: "1rem", marginBottom: "1rem", boxSizing: "border-box" }}
            />

            <ul style={{ listStyle: "none", padding: 0, margin: 0 }}>
              {filtered.map((hut) => (
                <li key={hut.id} style={{ border: "1px solid #e2e2e2", borderRadius: 8, padding: "0.9rem 1rem", marginBottom: "0.75rem" }}>
                  <div style={{ fontWeight: 600, fontSize: "1.05rem" }}>{hut.name}</div>
                  <div style={{ color: "#555", fontSize: "0.9rem", marginTop: "0.2rem" }}>
                    {typeLabel[hut.type] || hut.type}
                    {hut.region ? ` · ${hut.region}` : ""}
                    {hut.elevation ? ` · ${hut.elevation} m` : ""}
                  </div>
                  <div style={{ color: "#777", fontSize: "0.85rem", marginTop: "0.35rem" }}>
                    {hut.sleeping > 0 ? `${hut.sleeping} beds` : "no overnight"}
                    {" · "}
                    {hut.warden === "bewirtschaftet" ? "serviced" : hut.warden === "selbstversorger" ? "self-service" : "warden unknown"}
                    {hut.website ? <> {" · "} <a href={hut.website} target="_blank" rel="noreferrer">website</a></> : null}
                  </div>
                </li>
              ))}
            </ul>
          </>
        )}
      </div>
    </div>
  );
}